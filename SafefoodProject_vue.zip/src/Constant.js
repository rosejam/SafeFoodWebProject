export default{
    GET_QNALIST : 'getQnaList', //all
    GET_QNA : 'getQna',
    ADD_Q : 'addQ',
    ADD_A : 'addA', 
    REMOVE_QNA : 'removeQna',
    UPDATE_QNA : 'updateQna'
}